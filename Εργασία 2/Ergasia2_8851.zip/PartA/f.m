function res = f(x,y)
res = x.^3.*exp(-x.^2-y.^4);
end