function res = gradg(x,y)
res = [4.*x.^3-0.4*pi.*cos(2*pi.*x);2.*y+0.6*pi.*sin(2*pi.*y)];
end
