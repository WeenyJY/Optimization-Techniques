function res = g(x,y)
res = x.^4+y.^2-0.2.*sin(2*pi.*x)-0.3*cos(2*pi.*y);
end